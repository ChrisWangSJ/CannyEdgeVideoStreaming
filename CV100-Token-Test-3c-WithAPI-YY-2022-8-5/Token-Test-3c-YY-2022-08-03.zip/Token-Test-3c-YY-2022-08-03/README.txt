July 3, 2022, YY
CV100_Token_Testing_3c.py: Integrated TT2a Handwriting Recognition
Token-Test-3c-API-YY-2022-08-03: Client Side API, No memory leaking and handling video from eGlass
Token-Test-3c-WithAPI-YY-2022-08-03: Client Side Main with API. Build with arm64 API modules
